# Muholo Troubleshooter — Android prototype

A free, dark-theme Android starter app for device information, basic diagnostics,
and authorised repair-support workflows.

## Open the project
1. Install Android Studio.
2. Choose **Open** and select this `MuholoTroubleshooter` folder.
3. Allow Gradle to sync.
4. Connect an Android phone with USB debugging disabled; this prototype does not need ADB.
5. Press **Run** to install the app.

## Current prototype features
- Dashboard with detected device manufacturer, model and Android version.
- Device information screen.
- Basic diagnostic checklist.
- Placeholder repair history.
- Loan-lock support notice explaining the need for administrator authorisation.
- Dark black/green interface.

## Important limitations
This is a starter prototype, not a finished commercial repair product. It does not
unlock devices, bypass finance locks, access private identifiers, or change device
management policies. Loan-lock changes must be approved and performed through the
lender's authorised device-management process. Advanced hardware tests, persistent
history, customer support requests, and a Windows companion app are future work.

## Build an APK
In Android Studio, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
