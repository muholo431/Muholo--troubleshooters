package com.muholo.troubleshooter

import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090D0B)
private val Panel = Color(0xFF151D19)
private val Green = Color(0xFF35D07F)
private val Muted = Color(0xFFAAB8B0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MuholoApp() }
    }
}

@Composable
fun MuholoApp() {
    var selected by remember { mutableStateOf("Home") }
    var showInfo by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Green) {
                    listOf("Home", "Device", "Diagnostics", "History").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Home" -> Icons.Default.Home
                                        "Device" -> Icons.Default.PhoneAndroid
                                        "Diagnostics" -> Icons.Default.Build
                                        else -> Icons.Default.History
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green,
                                selectedTextColor = Green,
                                indicatorColor = Color(0xFF233B2D),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when(selected) {
                "Home" -> HomeScreen(Modifier.padding(padding), onOpenDevice = { selected = "Device" }, onOpenDiagnostics = { selected = "Diagnostics" })
                "Device" -> DeviceScreen(Modifier.padding(padding))
                "Diagnostics" -> DiagnosticsScreen(Modifier.padding(padding))
                else -> HistoryScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onOpenDevice: () -> Unit, onOpenDiagnostics: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("MUHOLO", color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("Troubleshooter", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Smart Android diagnostics & repair", color = Muted, fontSize = 14.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PhoneAndroid, null, tint = Green, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("THIS DEVICE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Android ${Build.VERSION.RELEASE}  •  API ${Build.VERSION.SDK_INT}", color = Muted)
                    Spacer(Modifier.height(14.dp))
                    Text("Device connected", color = Green, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item { Text("TOOLS", color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
        item { ToolCard("Device information", "View model, Android version and device details", Icons.Default.Info, onOpenDevice) }
        item { ToolCard("Run diagnostics", "Start basic checks on this phone", Icons.Default.MonitorHeart, onOpenDiagnostics) }
        item { ToolCard("Loan-lock support", "Check restrictions and request authorised assistance", Icons.Default.Lock, { }) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF18271E)), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Important", color = Green, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Muholo can inspect device information and guide authorised repairs. It cannot remove a lender's lock without approval from the device administrator.", color = Color(0xFFD5E2D9), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun ToolCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { action() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
fun DeviceScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle("Device information", "Details reported by this Android device")
        InfoRow("Manufacturer", Build.MANUFACTURER)
        InfoRow("Brand", Build.BRAND)
        InfoRow("Model", Build.MODEL)
        InfoRow("Device", Build.DEVICE)
        InfoRow("Android version", Build.VERSION.RELEASE)
        InfoRow("SDK/API level", Build.VERSION.SDK_INT.toString())
        InfoRow("Build ID", Build.DISPLAY)
        Text("Note: some identifiers are restricted by Android privacy protections.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun DiagnosticsScreen(modifier: Modifier = Modifier) {
    var ran by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenTitle("Diagnostics", "Basic checks available on this device")
        DiagnosticRow("Android system", "Available", true)
        DiagnosticRow("Battery information", "Available through system settings", true)
        DiagnosticRow("Storage access", "Not requested by this prototype", false)
        DiagnosticRow("USB repair connection", "Requires a Windows companion tool", false)
        DiagnosticRow("Loan device restriction", "Requires administrator-authorised status", false)
        Button(onClick = { ran = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) {
            Text("Run basic check", fontWeight = FontWeight.Bold)
        }
        if (ran) Text("Basic check completed. No device changes were made.", color = Green, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun HistoryScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle("Repair history", "Your activity on this device")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("No repair activity yet", fontWeight = FontWeight.Bold)
                Text("Diagnostic checks and authorised support requests will appear here in a future version.", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String) {
    Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
    Text(subtitle, color = Muted, fontSize = 13.sp)
}

@Composable
fun InfoRow(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Muted)
            Spacer(Modifier.width(12.dp))
            Text(value, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun DiagnosticRow(label: String, status: String, ok: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if(ok) Icons.Default.CheckCircle else Icons.Default.Info, null, tint = if(ok) Green else Muted)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(label, fontWeight = FontWeight.SemiBold)
                Text(status, color = Muted, fontSize = 12.sp)
            }
        }
    }
}
