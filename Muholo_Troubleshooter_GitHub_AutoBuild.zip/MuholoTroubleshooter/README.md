# Muholo Troubleshooter — Android starter project

A free, dark-theme Android starter app for device information, basic diagnostics,
and authorised repair-support workflows.

## Build an APK automatically with GitHub Actions

1. Create a free account or sign in at GitHub.
2. Create a **new private repository** named `muholo-troubleshooter`.
3. Upload the contents of this ZIP (not the ZIP itself) to the repository's `main` branch.
4. Open the repository's **Actions** tab. The `Build Android APK` workflow will run automatically.
5. When it finishes successfully, open the run, scroll to **Artifacts**, and download `Muholo-Troubleshooter-debug-apk`.
6. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

You can also run the workflow manually from **Actions > Build Android APK > Run workflow**.

## Open locally
1. Install Android Studio.
2. Choose **Open** and select this project folder.
3. Allow Gradle to sync, then press **Run**.

## Current prototype features
- Dashboard showing the device manufacturer, model and Android version.
- Device information screen.
- Basic diagnostic checklist.
- Placeholder repair history.
- Loan-lock support notice explaining the need for administrator authorisation.
- Dark black/green interface.

## Important limitations
This is a starter prototype, not a finished commercial repair product. It does not
unlock devices, bypass finance locks, access private identifiers, or change device
management policies. Loan-lock changes must be approved and performed through the
lender's authorised device-management process. Advanced hardware tests, persistent
history, customer support requests, and a Windows companion app are future work.
